package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

    public void performRepository() {
        // Repository logic
        System.out.println("Repository is working!");
    }
}
