package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void performService() {
        // Implement service logic
        System.out.println("Service is working!");
        bookRepository.performRepository(); // Example method call to demonstrate dependency injection
    }
}
