package com.library.repository;

public class BookRepository {
    // Implement repository logic
    public void performRepository() {
        System.out.println("Repository is working!");
    }
}
