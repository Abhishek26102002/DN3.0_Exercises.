for running the following maven projects *rename the file as "LibraryManagement" for each project to resolve potential error
